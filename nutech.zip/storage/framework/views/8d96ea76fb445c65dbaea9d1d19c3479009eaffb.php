<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <div id="app">
        <div class="container-fluid">
            <div class="row">
              <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <main class="col p-4">

                <?php echo $__env->yieldContent('content'); ?>
              </main>
            </div>
          </div>
    </div>

    <?php echo $__env->make('layouts.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH E:\NUTECH\BACKEND\nutech\resources\views/layouts/app.blade.php ENDPATH**/ ?>