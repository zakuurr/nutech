

<?php $__env->startSection('content'); ?>
<div class="container">
    <img src="<?php echo e(asset('')); ?>assets/img/profile.jpg" alt="profile picture" class="rounded-circle object-fit-cover mb-3" width="150px" height="150px">
    <h3 class="mb-3">Reza Kurnia</h3>
    <div class="row">
      <div class="col-8">
        <label class="form-label fw-semibold">Nama Kandidat</label>
        <div class="rounded border p-2">
          @&ensp;Reza Kurnia
        </div>
      </div>
      <div class="col-4">
        <label class="form-label fw-semibold">Posisi Kandidat</label>
        <div class="rounded border p-2">
          &lt;/&gt;&ensp;Web Programmer
        </div>
      </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NUTECH\BACKEND\nutech\resources\views/profile.blade.php ENDPATH**/ ?>