

<?php $__env->startSection('content'); ?>
<div class="container">
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(route('product.index')); ?>" class="text-black text-decoration-none"><h3>Daftar Produk</h3></a>
          </li>

        </ol>
      </nav>

    <div class="d-flex justify-content-between mb-4">
        <div class="d-flex gap-3">
          <form action="<?php echo e(route('product.index')); ?>" method="GET">
            <div class="wrapper">
              <input type="text" name="search" class="form-control input" placeholder="Cari Produk" value="<?php echo e(request('search')); ?>" style="width: 350px">
              <img src="<?php echo e(asset('')); ?>assets/img/magnifier.png" alt="icon" class="icon-lock" width="20">
            </div>
            <div class="wrapper">
                <select class="form-select input" name="category_id">
                    <option <?php echo e(request('category_id') == '' ? 'selected' : ''); ?> value="">Semua</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($category->id == request('category_id') ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              <img src="<?php echo e(asset('')); ?>assets/img/Package.png" alt="icon" class="icon-lock icon-black">
            </div>
            <button type="submit" class="btn btn-sm btn-outline-dark">Cari</button>
          </form>
        </div>
        <div>
          <div class="d-flex gap-3">
            <a href="/product/export?<?php echo e(http_build_query(request()->except('page'))); ?>">
              <button type="button" class="btn btn-sm btn-success">
                <img src="<?php echo e(asset('')); ?>assets/img/MicrosoftExcelLogo.png" alt="ExportLogo" width="20px" height="20px">
                Export Excel
              </button>
            </a>
            <a href="<?php echo e(route('product.create')); ?>" class="text-decoration-none">
              <button type="button" class="btn btn-sm btn-danger d-inline">
                <img src="<?php echo e(asset('')); ?>assets/img/PlusCircle.png" alt="TambahLogo" width="20px" height="20px">
                Tambah Produk
              </button>
            </a>
          </div>
        </div>
      </div>

    <div class="rounded border py-2 px-3 mb-3">

            <table class="table table-borderless">
                <thead class="table-light" >
                    <tr>
                      <th scope="col">No</th>
                      <th scope="col" class="text-center">Image</th>
                      <th scope="col">Nama Produk</th>
                      <th scope="col">Kategori Produk</th>
                      <th scope="col">Harga Barang (RP)</th>
                      <th scope="col">Harga Jual (RP)</th>
                      <th scope="col">Stok Produk</th>
                      <th scope="col" class="text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($products->firstItem() + $key); ?></td>
                      <td class="text-center"><img src="<?php echo e(asset('')); ?>assets/product/<?php echo e($product->gambar); ?>" alt="Image" height="20px"></td>

                      <td><?php echo e($product->nama_produk); ?></td>
                      <td><?php echo e($product->category->nama); ?></td>
                      <td><?php echo e(format_uang($product->harga_beli)); ?></td>
                      <td><?php echo e(format_uang($product->harga_jual)); ?></td>
                      <td><?php echo e($product->stok); ?></td>

                      <td class="text-center">
                        <a href="<?php echo e('/product/edit/'.$product->id); ?>" class="text-decoration-none">
                          <img src="<?php echo e(asset('')); ?>assets/img/edit.png" alt="icon" height="16px">
                        </a> &emsp;

                        <form method="POST" action="<?php echo e(route('product.destroy', $product->id)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" style="border: none;background-color: white"  class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete'><img src="<?php echo e(asset('')); ?>assets/img/delete.png" alt="icon" height="16px"></button>
                        </form>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <div class="alert alert-danger" role="alert">
                  Data Kosong!
                  </div>
                  <?php endif; ?>
                  </tbody>
            </table>

    </div>
    <?php echo e($products->links()); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NUTECH\BACKEND\nutech\resources\views/products/index.blade.php ENDPATH**/ ?>